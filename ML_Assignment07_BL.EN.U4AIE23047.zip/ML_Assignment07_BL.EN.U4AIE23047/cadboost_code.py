import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, RandomizedSearchCV
from catboost import CatBoostClassifier
from sklearn.metrics import accuracy_score, classification_report

# load dataset
def load_dataset(file_path):
    return pd.read_excel(file_path)

#Preprocessing data into X(features), y(target)
def preprocess_data(df):
    X = df.drop(columns=["Label"]).values
    y = df["Label"].values
    return X, y

# split dataset
def split_data(X, y, test_size=0.2, random_state=42):
    return train_test_split(X, y, test_size=test_size, random_state=random_state)

#hyperparameter tuning using RandomizedSearchCV
def tune_hyperparameters(model, param_grid, X_train, y_train, n_iter=20, cv=5):
    if param_grid:
        search = RandomizedSearchCV(model, param_distributions=param_grid,
                                    n_iter=n_iter, cv=cv, n_jobs=-1, verbose=1)
        search.fit(X_train, y_train)
        return search.best_estimator_
    return model

#train and evaluate a model
def train_and_evaluate(model, model_name, param_grid, X_train, X_test, y_train, y_test):
    model = tune_hyperparameters(model, param_grid, X_train, y_train)
    model.fit(X_train, y_train)
    y_train_pred = model.predict(X_train)
    y_test_pred = model.predict(X_test)

    train_acc = accuracy_score(y_train, y_train_pred)
    test_acc = accuracy_score(y_test, y_test_pred)

    print(f"{model_name} Results:")
    print(f"Train Accuracy: {train_acc:.4f}")
    print(f"Test Accuracy: {test_acc:.4f}")
    print("Classification Report:(Train)\n", classification_report(y_train, y_train_pred))
    print("Classification Report:(Test)\n", classification_report(y_test, y_test_pred))

    return model, train_acc, test_acc

def catboost_classifier(X_train, X_test, y_train, y_test):
    model = CatBoostClassifier(verbose=0,task_type="CPU")
    param_grid = {"iterations": [100, 200], "learning_rate": [0.01, 0.1, 0.2], "depth": [3, 6, 10]}
    return train_and_evaluate(model, "CatBoost", param_grid, X_train, X_test, y_train, y_test)

file_path = "Judgment_Embeddings_InLegalBERT.xlsx"
df = load_dataset(file_path)
X, y = preprocess_data(df)
X_train, X_test, y_train, y_test = split_data(X, y)

catboost_classifier(X_train, X_test, y_train, y_test)
