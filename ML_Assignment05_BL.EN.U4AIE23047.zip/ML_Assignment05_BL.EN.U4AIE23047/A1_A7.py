import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, mean_absolute_percentage_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, calinski_harabasz_score, davies_bouldin_score
import matplotlib.pyplot as plt

def load_data():
    """Loads the dataset from the Excel file."""
    return pd.read_excel("C:\\Users\\harsd\\OneDrive\\Desktop\\ML\\Judgment_Embeddings_InLegalBERT.xlsx", engine='openpyxl')

# A1: Linear Regression with one attribute
def linear_regression_one_attribute(data):
    X = data.iloc[:, :-1].values  # Features (using all except last column)
    y = data.iloc[:, -1].values   # Target (last column)
    X_train, X_test, y_train, y_test = train_test_split(X[:, [0]], y, test_size=0.2, random_state=42)
    model = LinearRegression().fit(X_train, y_train)
    y_train_pred = model.predict(X_train)
    y_test_pred = model.predict(X_test)
    return y_train, y_train_pred, y_test, y_test_pred

# A2: Calculate metrics
def calculate_metrics(y_true, y_pred):
    mse = mean_squared_error(y_true, y_pred)
    rmse = np.sqrt(mse)
    mape = mean_absolute_percentage_error(y_true, y_pred)
    r2 = r2_score(y_true, y_pred)
    return mse, rmse, mape, r2

# A3: Linear Regression with all attributes
def linear_regression_all_attributes(data):
    X = data.iloc[:, :-1].values  # Features (all except last column)
    y = data.iloc[:, -1].values   # Target (last column)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    model = LinearRegression().fit(X_train, y_train)
    y_train_pred = model.predict(X_train)
    y_test_pred = model.predict(X_test)
    return y_train, y_train_pred, y_test, y_test_pred

# A4: Perform k-means clustering
def perform_k_means(data, n_clusters):
    X = data.iloc[:, :-1].values
    kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init="auto").fit(X)
    return kmeans

# A5: Calculate clustering metrics
def calculate_clustering_metrics(data, kmeans):
    X = data.iloc[:, :-1].values
    silhouette = silhouette_score(X, kmeans.labels_)
    ch_score = calinski_harabasz_score(X, kmeans.labels_)
    db_index = davies_bouldin_score(X, kmeans.labels_)
    return silhouette, ch_score, db_index

# A6: Perform clustering for different k values and evaluate metrics
def evaluate_different_k(data):
    X = data.iloc[:, :-1].values
    results = []
    for k in range(2, 10):
        kmeans = KMeans(n_clusters=k, random_state=42, n_init="auto").fit(X)
        silhouette, ch_score, db_index = calculate_clustering_metrics(data, kmeans)
        results.append((k, silhouette, ch_score, db_index))
    return results

# A7: Elbow plot
def plot_elbow_method(data):
    X = data.iloc[:, :-1].values
    distortions = []
    for k in range(2, 10):
        kmeans = KMeans(n_clusters=k, random_state=42, n_init="auto").fit(X)
        distortions.append(kmeans.inertia_)
    plt.plot(range(2, 10), distortions, marker='o')
    plt.xlabel('Number of clusters')
    plt.ylabel('Distortion')
    plt.title('Elbow Method')
    plt.show()

if __name__ == "__main__":
    data = load_data()

    # A1 & A2
    y_train, y_train_pred, y_test, y_test_pred = linear_regression_one_attribute(data)
    train_metrics = calculate_metrics(y_train, y_train_pred)
    test_metrics = calculate_metrics(y_test, y_test_pred)
    print(f"Train Metrics (One Attribute): MSE={train_metrics[0]}, RMSE={train_metrics[1]}, MAPE={train_metrics[2]}, R2={train_metrics[3]}")
    print(f"Test Metrics (One Attribute): MSE={test_metrics[0]}, RMSE={test_metrics[1]}, MAPE={test_metrics[2]}, R2={test_metrics[3]}")

    # A3
    y_train, y_train_pred, y_test, y_test_pred = linear_regression_all_attributes(data)
    train_metrics = calculate_metrics(y_train, y_train_pred)
    test_metrics = calculate_metrics(y_test, y_test_pred)
    print(f"Train Metrics (All Attributes): MSE={train_metrics[0]}, RMSE={train_metrics[1]}, MAPE={train_metrics[2]}, R2={train_metrics[3]}")
    print(f"Test Metrics (All Attributes): MSE={test_metrics[0]}, RMSE={test_metrics[1]}, MAPE={test_metrics[2]}, R2={test_metrics[3]}")

    # A4 & A5
    kmeans = perform_k_means(data, 2)
    clustering_metrics = calculate_clustering_metrics(data, kmeans)
    print(f"Clustering Metrics (k=2): Silhouette={clustering_metrics[0]}, CH Score={clustering_metrics[1]}, DB Index={clustering_metrics[2]}")

    # A6
    results = evaluate_different_k(data)
    for k, silhouette, ch_score, db_index in results:
        print(f"k={k}: Silhouette={silhouette}, CH Score={ch_score}, DB Index={db_index}")

    # A7
    plot_elbow_method(data)
