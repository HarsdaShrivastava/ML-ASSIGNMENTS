arr=[2,7,4,1,3,6]

def calcsum(arr):
 for i in arr:
    for j in arr:
        if i+j==10:
            print(i,j)

calcsum(arr)
