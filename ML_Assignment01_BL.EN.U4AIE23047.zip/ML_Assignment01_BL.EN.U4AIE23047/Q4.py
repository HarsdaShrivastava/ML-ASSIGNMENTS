def calculate_letter_frequencies(input_word):

    frequency_dict = {}
    for character in input_word:
        if character in frequency_dict:
            frequency_dict[character] += 1
        else:
            frequency_dict[character] = 1
    return frequency_dict

def filter_frequent_letters(frequency_data, frequency_limit):

    result_list = []
    for character, count in frequency_data.items():
        if count > frequency_limit:
            result_list.append(character)
    return result_list


if __name__ == "__main__":
    given_word = "hippopotamus"
    letter_frequencies = calculate_letter_frequencies(given_word)
    frequent_characters = filter_frequent_letters(letter_frequencies, 3)
    for char in frequent_characters:
        print(char)
