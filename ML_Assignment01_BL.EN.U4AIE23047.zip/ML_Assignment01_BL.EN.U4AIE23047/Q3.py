def compute_matrix_power(matrix, exponent):

    output = matrix  # Start with the initial matrix
    for _ in range(1, exponent):  # Multiply the matrix by itself for (exponent - 1) iterations
        output = matrix_multiply(output, matrix)
    return output

def matrix_multiply(mat1, mat2):

    size = len(mat1)
    result = [[0] * size for _ in range(size)]
    for i in range(size):
        for j in range(size):
            for k in range(size):
                result[i][j] += mat1[i][k] * mat2[k][j]
    return result


if __name__ == "__main__":
    matrix = [[2, 1], [1, 2]]
    power = 3
    final_result = compute_matrix_power(matrix, power)
    print(f"The matrix raised to the power {power} is:")
    for row in final_result:
        print(row)
