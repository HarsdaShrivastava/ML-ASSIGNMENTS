def find_range(values):

    if len(values) < 3:
        return "Cannot calculate the range, the list is too short"
    return max(values) - min(values)

# Main program for Question 2
if __name__ == "__main__":
    values = [5, 3, 8, 1, 0, 4]
    result = find_range(values)
    print(f"The range of the given list is: {result}")
