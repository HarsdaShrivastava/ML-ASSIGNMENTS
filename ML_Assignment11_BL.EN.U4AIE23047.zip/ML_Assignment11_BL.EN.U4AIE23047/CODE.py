import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.model_selection import train_test_split
from sklearn.feature_selection import SequentialFeatureSelector
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report
from lime.lime_tabular import LimeTabularExplainer
import shap

def load_data(filepath):
    df = pd.read_excel(filepath)
    X = df.drop(columns=["Label"]).values
    y = df["Label"].values
    feature_names = df.drop(columns=["Label"]).columns
    return df, X, y, feature_names

# A1: Correlation heatmap
def plot_correlation_heatmap(df):
    plt.figure(figsize=(12, 10))
    corr = df.drop(columns=["Label"]).corr()
    sns.heatmap(corr, annot=False, cmap='coolwarm')
    plt.title("Feature Correlation Heatmap")
    plt.show()

# Preprocessing
def preprocess_and_split(X, y):
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    return train_test_split(X_scaled, y, test_size=0.2, random_state=42), scaler

# Model Evaluation
def evaluate_model(model, X_train, X_test, y_train, y_test, title=""):
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    print(f"\n{title}")
    print("Accuracy:", acc)
    print(classification_report(y_test, y_pred))
    return acc

# A2, A3: PCA-based feature reduction and classification
def run_pca_and_classify(X_scaled, y, variance_threshold, model):
    pca = PCA(n_components=variance_threshold)
    X_pca = pca.fit_transform(X_scaled)
    X_train, X_test, y_train, y_test = train_test_split(X_pca, y, test_size=0.2, random_state=42)
    acc = evaluate_model(model, X_train, X_test, y_train, y_test, f"PCA ({int(variance_threshold * 100)}% Variance)")
    return acc, X_pca, pca

# A4: Sequential feature selection
def run_sequential_feature_selection(X_scaled, y, model, feature_names):
    sfs = SequentialFeatureSelector(model, direction='forward', scoring='accuracy', cv=2, n_features_to_select=20, n_jobs=-1)
    sfs.fit(X_scaled, y)
    selected_mask = sfs.get_support()
    X_selected = X_scaled[:, selected_mask]
    selected_features = feature_names[selected_mask]

    X_train, X_test, y_train, y_test = train_test_split(X_selected, y, test_size=0.2, random_state=42)
    acc = evaluate_model(model, X_train, X_test, y_train, y_test, "Sequential Feature Selection")
    return acc, selected_features, X_selected

# A5: LIME and SHAP explainability
def explain_with_lime_and_shap(model, X_train, y_train, feature_names):
    model.fit(X_train, y_train)

    print("\nLIME Explanation")
    lime_explainer = LimeTabularExplainer(
        X_train, feature_names=feature_names,
        class_names=np.unique(y_train).astype(str),
        discretize_continuous=True
    )
    exp = lime_explainer.explain_instance(X_train[0], model.predict_proba, num_features=10)
    exp.show_in_notebook()

    print("\nSHAP Explanation")
    shap_explainer = shap.Explainer(model, X_train)
    shap_values = shap_explainer(X_train[:100])
    shap.summary_plot(shap_values, X_train[:100], feature_names=feature_names)

# Entire pipeline
def main_pipeline(filepath):
    df, X, y, feature_names = load_data(filepath)

    # A1: Heatmap
    plot_correlation_heatmap(df)

    # Preprocessing
    (X_train, X_test, y_train, y_test), scaler = preprocess_and_split(X, y)
    X_scaled = scaler.transform(X)

    model = RandomForestClassifier(n_estimators=50, random_state=42)  

    # A2: PCA with 99% variance
    acc_pca_99, X_pca_99, _ = run_pca_and_classify(X_scaled, y, 0.99, model)

    # A3: PCA with 95% variance
    acc_pca_95, X_pca_95, _ = run_pca_and_classify(X_scaled, y, 0.95, model)

    # A4: Sequential Feature Selection
    acc_sfs, selected_features, X_selected = run_sequential_feature_selection(X_scaled, y, model, feature_names)

    # A5: Explainability
    explain_with_lime_and_shap(model, X_train, y_train, feature_names)

    # Summary
    print("\nAccuracy Summary")
    print(f"PCA 99% Variance Accuracy: {acc_pca_99:.4f}")
    print(f"PCA 95% Variance Accuracy: {acc_pca_95:.4f}")
    print(f"Sequential Feature Selection Accuracy: {acc_sfs:.4f}")

main_pipeline("Judgment_Embeddings_InLegalBERT.xlsx")
